﻿namespace WinFormsApp1
{
    partial class AnaSayfa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_DosyaEkle = new Button();
            textBox_DosyaIcerigi = new TextBox();
            label_DosyaIsim = new Label();
            label_DosyaOrnegi = new Label();
            label_AranacakKelime = new Label();
            btn_KelimeAra = new Button();
            textBox_AranacakKelime = new TextBox();
            btn_MorfolojikAnaliz = new Button();
            textBox_DosyaIsim = new TextBox();
            groupBox1 = new GroupBox();
            groupBox2 = new GroupBox();
            groupBox3 = new GroupBox();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // btn_DosyaEkle
            // 
            btn_DosyaEkle.Location = new Point(610, 46);
            btn_DosyaEkle.Margin = new Padding(4, 3, 4, 3);
            btn_DosyaEkle.Name = "btn_DosyaEkle";
            btn_DosyaEkle.Size = new Size(120, 51);
            btn_DosyaEkle.TabIndex = 0;
            btn_DosyaEkle.Text = "Dosya Ekle";
            btn_DosyaEkle.UseVisualStyleBackColor = true;
            btn_DosyaEkle.Click += btn_DosyaEkle_Click;
            // 
            // textBox_DosyaIcerigi
            // 
            textBox_DosyaIcerigi.Location = new Point(206, 130);
            textBox_DosyaIcerigi.Margin = new Padding(4, 3, 4, 3);
            textBox_DosyaIcerigi.Multiline = true;
            textBox_DosyaIcerigi.Name = "textBox_DosyaIcerigi";
            textBox_DosyaIcerigi.Size = new Size(416, 131);
            textBox_DosyaIcerigi.TabIndex = 2;
            // 
            // label_DosyaIsim
            // 
            label_DosyaIsim.AutoSize = true;
            label_DosyaIsim.Location = new Point(41, 65);
            label_DosyaIsim.Margin = new Padding(4, 0, 4, 0);
            label_DosyaIsim.Name = "label_DosyaIsim";
            label_DosyaIsim.Size = new Size(73, 15);
            label_DosyaIsim.TabIndex = 3;
            label_DosyaIsim.Text = "Dosya İsmi : ";
            // 
            // label_DosyaOrnegi
            // 
            label_DosyaOrnegi.AutoSize = true;
            label_DosyaOrnegi.Location = new Point(84, 134);
            label_DosyaOrnegi.Margin = new Padding(4, 0, 4, 0);
            label_DosyaOrnegi.Name = "label_DosyaOrnegi";
            label_DosyaOrnegi.Size = new Size(109, 15);
            label_DosyaOrnegi.TabIndex = 4;
            label_DosyaOrnegi.Text = "Dosya Önizlemesi : ";
            // 
            // label_AranacakKelime
            // 
            label_AranacakKelime.AutoSize = true;
            label_AranacakKelime.Location = new Point(33, 47);
            label_AranacakKelime.Margin = new Padding(4, 0, 4, 0);
            label_AranacakKelime.Name = "label_AranacakKelime";
            label_AranacakKelime.Size = new Size(104, 15);
            label_AranacakKelime.TabIndex = 5;
            label_AranacakKelime.Text = "Aranacak Kelime : ";
            // 
            // btn_KelimeAra
            // 
            btn_KelimeAra.Location = new Point(139, 102);
            btn_KelimeAra.Margin = new Padding(4, 3, 4, 3);
            btn_KelimeAra.Name = "btn_KelimeAra";
            btn_KelimeAra.Size = new Size(120, 51);
            btn_KelimeAra.TabIndex = 6;
            btn_KelimeAra.Text = "Kelime Ara";
            btn_KelimeAra.UseVisualStyleBackColor = true;
            btn_KelimeAra.Click += btn_KelimeAra_Click;
            // 
            // textBox_AranacakKelime
            // 
            textBox_AranacakKelime.Location = new Point(152, 44);
            textBox_AranacakKelime.Margin = new Padding(4, 3, 4, 3);
            textBox_AranacakKelime.Name = "textBox_AranacakKelime";
            textBox_AranacakKelime.Size = new Size(202, 23);
            textBox_AranacakKelime.TabIndex = 7;
            // 
            // btn_MorfolojikAnaliz
            // 
            btn_MorfolojikAnaliz.Location = new Point(126, 102);
            btn_MorfolojikAnaliz.Margin = new Padding(4, 3, 4, 3);
            btn_MorfolojikAnaliz.Name = "btn_MorfolojikAnaliz";
            btn_MorfolojikAnaliz.Size = new Size(120, 51);
            btn_MorfolojikAnaliz.TabIndex = 8;
            btn_MorfolojikAnaliz.Text = "Morfolojik Analiz Getir";
            btn_MorfolojikAnaliz.UseVisualStyleBackColor = true;
            btn_MorfolojikAnaliz.Click += btn_MorfolojikAnaliz_Click;
            // 
            // textBox_DosyaIsim
            // 
            textBox_DosyaIsim.Location = new Point(126, 61);
            textBox_DosyaIsim.Margin = new Padding(4, 3, 4, 3);
            textBox_DosyaIsim.Name = "textBox_DosyaIsim";
            textBox_DosyaIsim.Size = new Size(410, 23);
            textBox_DosyaIsim.TabIndex = 9;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label_DosyaOrnegi);
            groupBox1.Controls.Add(textBox_DosyaIcerigi);
            groupBox1.Controls.Add(label_DosyaIsim);
            groupBox1.Controls.Add(btn_DosyaEkle);
            groupBox1.Controls.Add(textBox_DosyaIsim);
            groupBox1.Location = new Point(14, 14);
            groupBox1.Margin = new Padding(4, 3, 4, 3);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(4, 3, 4, 3);
            groupBox1.Size = new Size(797, 318);
            groupBox1.TabIndex = 10;
            groupBox1.TabStop = false;
            groupBox1.Text = "Dosya Yeri";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(btn_KelimeAra);
            groupBox2.Controls.Add(label_AranacakKelime);
            groupBox2.Controls.Add(textBox_AranacakKelime);
            groupBox2.Location = new Point(14, 339);
            groupBox2.Margin = new Padding(4, 3, 4, 3);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(4, 3, 4, 3);
            groupBox2.Size = new Size(396, 193);
            groupBox2.TabIndex = 11;
            groupBox2.TabStop = false;
            groupBox2.Text = "RegEx";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(btn_MorfolojikAnaliz);
            groupBox3.Location = new Point(416, 339);
            groupBox3.Margin = new Padding(4, 3, 4, 3);
            groupBox3.Name = "groupBox3";
            groupBox3.Padding = new Padding(4, 3, 4, 3);
            groupBox3.Size = new Size(394, 193);
            groupBox3.TabIndex = 12;
            groupBox3.TabStop = false;
            groupBox3.Text = "Morfolojik Analiz";
            // 
            // AnaSayfa
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(828, 553);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Margin = new Padding(4, 3, 4, 3);
            Name = "AnaSayfa";
            Text = "Ana Sayfa";
            Load += AnaSayfa_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            ResumeLayout(false);
        }

        

        #endregion

        private Button btn_DosyaEkle;
        private TextBox textBox_DosyaIcerigi;
        private Label label_DosyaIsim;
        private Label label_DosyaOrnegi;
        private Label label_AranacakKelime;
        private Button btn_KelimeAra;
        private TextBox textBox_AranacakKelime;
        private Button btn_MorfolojikAnaliz;
        private TextBox textBox_DosyaIsim;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private GroupBox groupBox3;
    }
}