﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class RegExAra : Form
    {
        public RegExAra(string[] TextData, string regexPattern)
        {
            InitializeComponent();
            listBox_RegEx.Items.Clear();
            listBoxMatchDataAdd(TextData , regexPattern);
        }

        private void listBoxMatchDataAdd(string[] txtDat, string regPat)
        {
            foreach (string item in txtDat)
            {
                if (Regex.IsMatch(item, regPat))
                {
                    // Add matching strings to the ListBox
                    listBox_RegEx.Items.Add(item);
                }
            }

            if (listBox_RegEx.Items.Count == 0)
            {
                MessageBox.Show("İstediğiniz kelime bulunamadı", "UYARI", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }
        }

        private void ReGexAra_Load(object sender, EventArgs e)
        {

        }

    }
}
