using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using Python.Runtime;
using static System.Net.Mime.MediaTypeNames;

namespace WinFormsApp1
{
    public partial class AnaSayfa : Form
    {
        public AnaSayfa()
        {
            InitializeComponent();
            // Replace the path below with the path of your own pyhton311.dll file (your Python version must be python311, otherwise the code will not work)
            Runtime.PythonDLL = @"C:\Users\utkub\AppData\Local\Programs\Python\Python311\python311.dll";
            PythonEngine.Initialize();
            dynamic sys = Py.Import("sys");
            // Replace the path below with the location where you downloaded this application (for example, this file was on our desktop)
            sys.path.append(@"C:\Users\utkub\Desktop\WinFormsApp1\WinFormsApp1");
        }


        // Create an OpenFileDialog object.
        OpenFileDialog openFileDialog = new OpenFileDialog();
        string[] v;

        private void RegEx_Arama(string[] TextContent, string Pattern)
        {
            // Use regular expressions to search for the pattern
            RegExAra RegExAra = new RegExAra(TextContent, Pattern);
            RegExAra.Show();
        }

        private void AnaSayfa_Load(object sender, EventArgs e)
        {

        }

        private void btn_DosyaEkle_Click(object sender, EventArgs e)
        {
            // Set the filter to allow the user to select only text files.
            openFileDialog.Filter = "Text files (*.txt)|*.txt";
            openFileDialog.Title = "Bir Dosya Se�in";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Get the path to the selected file.
                string FilePath = openFileDialog.FileName;
                textBox_DosyaIsim.Text = FilePath;

                // Read the content of the selected text file
                string FileContent = File.ReadAllText(FilePath);

                // Display the content in the TextBox
                textBox_DosyaIcerigi.Text = "Se�ilen dosyan�n �nizlemesi :";
                textBox_DosyaIcerigi.Text += "\r\n" + "\r\n";
                textBox_DosyaIcerigi.Text += FileContent;
            }
            else
            {
                MessageBox.Show("Dosya A��lamad�", "UYARI", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }
        }

        private void btn_KelimeAra_Click(object sender, EventArgs e)
        {
            string pattern = @"" + textBox_AranacakKelime.Text;
            //Regex RegExWord = new Regex(textBox_AranacakKelime.Text);
            wordDivide();
            RegEx_Arama(v, pattern);
        }

        private void btn_MorfolojikAnaliz_Click(object sender, EventArgs e)
        {
            // Read the content of the selected text file
            if (openFileDialog.FileName=="")
            {
                MessageBox.Show("Metin se�ilemedi", "UYARI", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }
            else
            {
                string FileContent = File.ReadAllText(openFileDialog.FileName);
                wordDivide();


                string RemovedFileContent = RemovePunctuation(FileContent);

                using (Py.GIL())
                {
                    var pythonScript = Py.Import("PythonDosyasi");

                    var message = new PyString(RemovedFileContent);

                    var resultSpellingCorrection = pythonScript.InvokeMethod("Analysis", message);

                    string MorfolojikText = resultSpellingCorrection.ToString();


                    string[] words = textToWordArray(RemovedFileContent);

                    string[] morfolojikWord=new string[words.Length];

                    int counter = 0;
                    foreach (var item in words)
                    {
                        PyString pyStrWord = new PyString(item);
                        var wordAnalys = pythonScript.InvokeMethod("SingleWordAnalysis", pyStrWord);
                        morfolojikWord[counter]= wordAnalys.ToString();
                        counter++;
                    }

                    MorfolojikAnaliz morfolojikAnaliz = new MorfolojikAnaliz(MorfolojikText, uniqueWord(words) ,uniqueWord(morfolojikWord));
                    morfolojikAnaliz.Show();
                }
            }
        }
        

        private void wordDivide()
        {
            string[] satirlar = File.ReadAllLines(openFileDialog.FileName);
            v = satirlar;
        }


        private string[] textToWordArray(string text)
        {
            string[] desen = { " ", "\n", "\r" };
            string[] wordArray = text.Split(desen , StringSplitOptions.RemoveEmptyEntries);
            return wordArray;
        }

        // finds unique words and return
        private List<string> uniqueWord(string[] words)
        {
            List<string> uniqueWordArr =new List<string>();
            
            for (int i = 0; i < words.Length; i++)
            {
                if (isWordUnique(uniqueWordArr, words[i]))
                {
                    uniqueWordArr.Add(words[i]); 
                }
            }
            return uniqueWordArr;
        }

        private bool isWordUnique(List<string> arr, string word)
        {
            for (int k = 0; k < arr.Count; k++)
            {
                if (word == arr[k])
                {
                    return false;
                }
            }
            return true;
        }

        static string RemovePunctuation(string input)
        {
            // Regex deseni ile t�m noktalama i�aretlerini bul ve kald�r
            string pattern = @"[\p{P}]+";
            MessageBox.Show("Noktalama i�aretleri silindi.\n\n Yaz�m hatalar� d�zeltidi", "Bilgilendirme", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            return Regex.Replace(input, pattern, string.Empty);
        }
    }
}