import time
import logging

from zemberek import (
    TurkishSpellChecker,
    TurkishSentenceNormalizer,
    TurkishSentenceExtractor,
    TurkishMorphology,
    TurkishTokenizer
)

morphology = TurkishMorphology.create_with_defaults()
extractor = TurkishSentenceExtractor()

def Analysis(txtFileContent):

	# SENTENCE NORMALIZATION
    normalizer = TurkishSentenceNormalizer(morphology)
    text = "------------------------------" + "\r\n" + "\r\n" + "Yazilarin ilk hali : " 
    text += "\r\n" + "\r\n"
    text += txtFileContent 
    text += "\r\n" + "\r\n" + "------------------------------" + "\r\n" + "\r\n"
    text += "Yazilarin normalize edilmis hali : "
    text += "\r\n" + "\r\n" 
    text += normalizer.normalize(txtFileContent)
    return(text)

def SingleWordAnalysis(word):
    results = morphology.analyze(word)
    analysResult=""
    for result in results:
       analysResult += str(result) + " "
    return analysResult

def textSentenceFind(paragraph):
    sentences = extractor.from_paragraph(paragraph)
    result=[]
    for sentence in sentences:
        result.append(sentence)
    return result


