﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class MorfolojikAnaliz : Form
    {
        public MorfolojikAnaliz(string textFile, List<string> uniqueWords, List<string> analysisWord)
        {
            InitializeComponent();
            textBox_MorfolojikAnaliz.Clear();
            textBox_MorfolojikAnaliz.Text = textFile;
            textBox_MorfolojikAnaliz.Text += "\r\n" + "\r\n" + "------------------------------" + "\r\n" + "\r\n";
            textBox_MorfolojikAnaliz.Text += "BENZERSİZ KELİMELER : ";
            textBox_MorfolojikAnaliz.Text += "\r\n" + "\r\n";
            int count = 1;
            foreach (string word in uniqueWords) 
            {
                textBox_MorfolojikAnaliz.Text += count + ".bensersiz kelime : " + word + "\r\n" + "\r\n";
                count++;
            }

            foreach (string word in analysisWord)
            {
                textBox_MorfolojikAnaliz.Text += count + ".bensersiz kelime : " + word + "\r\n" + "\r\n";
                count++;
            }
        }

        private void MorfolojikAnaliz_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
